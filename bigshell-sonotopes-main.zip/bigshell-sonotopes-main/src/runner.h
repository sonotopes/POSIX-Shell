/* XXX DO NOT MODIFY XXX */
#pragma once
#include "parser.h"

/** Exactly what it sounds like
 *
 * @returns 0 on success, -1 on error
 */
extern int run_command_list(struct command_list *cl);
